class Suggestion < ActiveRecord::Base
  attr_protected
end
