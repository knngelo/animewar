class Comment < ActiveRecord::Base
  attr_protected
end
