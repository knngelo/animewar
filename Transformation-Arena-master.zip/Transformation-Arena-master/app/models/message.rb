class Message < ActiveRecord::Base
  # attr_accessible :title, :body
  attr_protected 
end
