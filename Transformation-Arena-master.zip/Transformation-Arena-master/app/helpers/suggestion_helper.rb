module SuggestionHelper
end
