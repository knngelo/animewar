# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
DuelOfChampions::Application.config.secret_token = '42b02c6ce32066ec2b61c6f13a9358c67e24876c86907a4f3b97e107cf2608f5b19bca9d8d721a0c04e4f7d0c08141062f9b586d1621c276acdc002b909a8442'
