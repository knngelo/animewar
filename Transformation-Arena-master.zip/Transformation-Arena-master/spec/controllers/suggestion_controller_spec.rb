require 'rails_helper'

RSpec.describe SuggestionController, :type => :controller do

end
