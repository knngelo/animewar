require 'rails_helper'

RSpec.describe ReportController, :type => :controller do

end
