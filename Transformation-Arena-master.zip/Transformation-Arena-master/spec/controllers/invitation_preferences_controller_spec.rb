require 'rails_helper'

RSpec.describe InvitationPreferencesController, :type => :controller do

end
