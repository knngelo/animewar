require 'rails_helper'

RSpec.describe CommentController, :type => :controller do

end
