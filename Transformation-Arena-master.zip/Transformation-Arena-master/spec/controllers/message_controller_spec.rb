require 'rails_helper'

RSpec.describe MessageController, :type => :controller do

end
