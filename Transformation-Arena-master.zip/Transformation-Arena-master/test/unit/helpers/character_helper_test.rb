require 'test_helper'

class CharacterHelperTest < ActionView::TestCase
end
